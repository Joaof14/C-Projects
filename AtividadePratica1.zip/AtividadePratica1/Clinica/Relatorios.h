#ifndef RELATORIOS_H
#define RELATORIOS_H


void menuRelatorios();
void relatorioConsultaPacientes();
void relatorioConsultaMedicos();
void relatorioConsultaPorEspecialidae();
void relatorioConsultaDiaAtual();


#endif